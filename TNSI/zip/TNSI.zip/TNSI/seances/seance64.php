<section id="session64" class="content-section">
            <h2>Séance 64 : Introduction aux Protocoles de Sécurité (SSL, HTTPS)</h2>
        
            <h3>Objectif Global :</h3>
            <p>Les élèves apprendront les bases des protocoles de 
sécurité en informatique, notamment SSL (Secure Sockets Layer) et HTTPS 
(HyperText Transfer Protocol Secure). Cette séance vise à expliquer leur
 fonctionnement, leur rôle dans la sécurisation des communications, et à
 illustrer leur application à travers des exemples pratiques.</p>
        
            <h3>1. Contexte et Importance des Protocoles de Sécurité</h3>
        
            <h4>Pourquoi les Protocoles de Sécurité sont-ils Importants ?</h4>
            <p>Les protocoles de sécurité sont essentiels pour protéger les échanges de données sur Internet. Ils garantissent :</p>
            <ul>
                <li><strong>Confidentialité :</strong> Les données échangées sont chiffrées pour empêcher leur lecture par des tiers.</li>
                <li><strong>Authenticité :</strong> Les parties en communication peuvent vérifier leur identité mutuelle.</li>
                <li><strong>Intégrité :</strong> Les données ne peuvent pas être modifiées ou altérées pendant leur transfert.</li>
            </ul>
        
            <h4>Exemples de Menaces Courantes :</h4>
            <ul>
                <li>Interception des données par un attaquant (attaque de l’homme du milieu).</li>
                <li>Sites Web frauduleux imitant des sites légitimes pour voler des informations (hameçonnage).</li>
                <li>Altération des données pendant leur transfert.</li>
            </ul>
        
            <h3>2. Comprendre SSL et TLS (20 min)</h3>
        
            <h4>Qu’est-ce que SSL ?</h4>
            <p>
                SSL (Secure Sockets Layer) est un protocole qui établit 
une connexion sécurisée entre un client (navigateur) et un serveur. Il 
utilise des techniques de chiffrement pour protéger les données 
échangées.
            </p>
        
            <h4>Qu’est-ce que TLS ?</h4>
            <p>
                TLS (Transport Layer Security) est une version améliorée
 et plus sécurisée de SSL. Aujourd’hui, TLS a remplacé SSL, mais le 
terme SSL est souvent utilisé par commodité pour désigner les deux.
            </p>
        
            <h4>Fonctionnement de SSL/TLS :</h4>
            <p>SSL/TLS repose sur les concepts suivants :</p>
            <ul>
                <li><strong>Chiffrement :</strong> Les données sont chiffrées pour garantir leur confidentialité.</li>
                <li><strong>Certificats :</strong> Un certificat SSL/TLS est utilisé pour vérifier l’identité du serveur.</li>
                <li><strong>Négociation :</strong> Le client et le serveur négocient un "canal sécurisé" pour échanger les données.</li>
            </ul>
        
            <h4>Schéma de Fonctionnement :</h4>
            <pre><code>1. Le client (navigateur) contacte le serveur et demande une connexion sécurisée.
        2. Le serveur envoie son certificat SSL/TLS au client.
        3. Le client vérifie le certificat pour s'assurer qu'il est valide.
        4. Le client et le serveur établissent un canal chiffré.
        5. Les données sont échangées en toute sécurité.
            </code></pre>
        
            <h3>3. Comprendre HTTPS (HyperText Transfer Protocol Secure)</h3>
        
            <h4>Qu’est-ce que HTTPS ?</h4>
            <p>
                HTTPS est une version sécurisée de HTTP qui utilise 
SSL/TLS pour protéger les données échangées entre le client et le 
serveur. HTTPS est indispensable pour des applications comme :
            </p>
            <ul>
                <li>Les transactions financières (paiements en ligne).</li>
                <li>La connexion à des comptes utilisateur.</li>
                <li>La navigation sur des sites Web sensibles.</li>
            </ul>
        
            <h4>Différence entre HTTP et HTTPS :</h4>
            <table border="1" style="border-collapse: collapse; width: 100%; text-align: left;">
                <thead>
                    <tr>
                        <th>HTTP</th>
                        <th>HTTPS</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Les données échangées ne sont pas chiffrées.</td>
                        <td>Les données sont chiffrées et protégées.</td>
                    </tr>
                    <tr>
                        <td>Pas de certificat SSL/TLS requis.</td>
                        <td>Requiert un certificat SSL/TLS.</td>
                    </tr>
                    <tr>
                        <td>Vulnérable aux attaques.</td>
                        <td>Protège contre les interceptions et les altérations.</td>
                    </tr>
                </tbody>
            </table>
        
            <h4>Indicateurs Visuels de HTTPS :</h4>
            <p>Sur un navigateur Web, un site HTTPS est indiqué par :</p>
            <ul>
                <li>Un cadenas dans la barre d’adresse.</li>
                <li>L’URL commençant par <code>https://</code>.</li>
            </ul>
        
            <h3>4. Mise en Pratique (40 min)</h3>
        
            <h4>Exercice : Vérifier un Certificat SSL/TLS</h4>
            <p>
                Les élèves utiliseront leur navigateur pour vérifier les certificats SSL/TLS de plusieurs sites Web.
            </p>
            <ul>
                <li><strong>Étape 1 :</strong> Accédez à un site HTTPS (par exemple, https://www.google.com).</li>
                <li><strong>Étape 2 :</strong> Cliquez sur le cadenas dans la barre d’adresse.</li>
                <li><strong>Étape 3 :</strong> Examinez les informations du certificat (organisation, validité, autorité de certification).</li>
            </ul>

            <h2>Exercice : Configurer un Site Local avec HTTPS</h2>

            <h3>Objectif :</h3>
            <p>
                Configurer un serveur local sécurisé avec HTTPS en 
utilisant Python et OpenSSL. Cet exercice permettra de comprendre les 
étapes nécessaires pour mettre en place un certificat SSL/TLS et de 
tester HTTPS dans un environnement local.
            </p>

            <h3>Prérequis :</h3>
            <ul>
                <li>Python (version 3.7 ou supérieure) installé.</li>
                <li>OpenSSL installé (disponible par défaut sur Linux/Mac, téléchargeable pour Windows).</li>
                <li>Un éditeur de texte et un terminal (par exemple, VS Code, Terminal ou Command Prompt).</li>
            </ul>

            <h3>Étape 1 : Créer un Certificat SSL/TLS Auto-signé</h3>
            <p>
                Un certificat auto-signé sera généré pour sécuriser les 
communications. Cela convient uniquement pour un usage local (non 
recommandé en production).
            </p>

            <h4>Commandes à Exécuter :</h4>
            <pre><code class="bash">
        # 1. Générer une clé privée
        openssl genrsa -out cle_privee.key 2048

        # 2. Créer une demande de signature de certificat (CSR)
        openssl req -new -key cle_privee.key -out demande_signature.csr

        # Pendant cette étape, fournissez les informations demandées :
        # - Country Name (e.g., FR)
        # - State or Province Name
        # - Locality Name
        # - Organization Name
        # - Common Name (utilisez "localhost" pour usage local)

        # 3. Générer un certificat auto-signé (valable 365 jours)
        openssl x509 -req -days 365 -in demande_signature.csr -signkey cle_privee.key -out certificat.crt
            </code></pre>

            <h4>Fichiers Générés :</h4>
            <ul>
                <li><code>cle_privee.key</code> : Clé privée du serveur.</li>
                <li><code>certificat.crt</code> : Certificat SSL auto-signé.</li>
                <li><code>demande_signature.csr</code> : Demande de signature (optionnelle ici).</li>
            </ul>

            <h3>Étape 2 : Configurer un Serveur Local avec HTTPS</h3>

            <h4>Création d’un Fichier HTML Simple :</h4>
            <p>Créez un fichier <code>index.html</code> avec le contenu suivant :</p>
            <pre><code class="html">
        
        
        
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Serveur HTTPS Local</title>
        
        
            <h1>Bienvenue sur le serveur HTTPS local !</h1>
            <p>Ce site est sécurisé avec HTTPS (certificat auto-signé).</p>
        
        
            </code></pre>

            <h4>Lancement du Serveur HTTPS :</h4>
            <p>
                Dans le même répertoire que les fichiers, exécutez la commande suivante pour démarrer un serveur HTTPS&nbsp;:
            </p>
            <pre><code class="bash">
        python -m http.server 8000 --bind 127.0.0.1 --certfile certificat.crt --keyfile cle_privee.key
            </code></pre>

            <h4>Explication des Options :</h4>
            <ul>
                <li><code>8000</code> : Port du serveur.</li>
                <li><code>--bind 127.0.0.1</code> : Limite le serveur à localhost.</li>
                <li><code>--certfile certificat.crt</code> : Chemin vers le certificat SSL.</li>
                <li><code>--keyfile cle_privee.key</code> : Chemin vers la clé privée.</li>
            </ul>

            <h3>Étape 3 : Tester le Serveur HTTPS</h3>
            <ol>
                <li>Ouvrez un navigateur Web (Chrome, Firefox, Edge, etc.).</li>
                <li>Accédez à l’URL suivante : <code>https://localhost:8000</code>.</li>
            </ol>

            <h4>Que Se Passe-t-il ?</h4>
            <ul>
                <li>Votre navigateur affichera un avertissement 
indiquant que le certificat n’est pas fiable (c’est normal pour un 
certificat auto-signé).</li>
                <li>Cliquez sur <strong>“Avancé”</strong> puis <strong>“Continuer vers localhost”</strong> pour accéder au site.</li>
            </ul>

            <h4>Résultat Attendu :</h4>
            <p>Le navigateur affichera le contenu de votre fichier <code>index.html</code>.</p>

            <h3>Étape 4 : Comprendre les Limites</h3>
            <p>
                Un certificat auto-signé est suffisant pour les tests 
locaux, mais en production, vous devez utiliser un certificat signé par 
une autorité de certification (CA) reconnue comme Let’s Encrypt.
            </p>

            <h3>Étape 5 : Défi Supplémentaire</h3>
            <p>Pour aller plus loin, essayez les activités suivantes :</p>
            <ul>
                <li><strong>Intercepter les Requêtes :</strong> Utilisez un outil comme Wireshark pour capturer et analyser les données échangées.</li>
                <li><strong>Ajouter des Pages :</strong> Créez plusieurs fichiers HTML (par exemple, <code>page1.html</code>, <code>page2.html</code>) et testez leur navigation sur le serveur HTTPS.</li>
                <li><strong>Configurer HTTPS avec un Serveur Web Complet :</strong> Essayez de configurer un serveur local sécurisé avec Apache ou Nginx.</li>
            </ul>

            <h3>Conclusion :</h3>
            <p>
                À la fin de cet exercice, vous aurez appris :
            </p>
            <ul>
                <li>À générer un certificat SSL/TLS.</li>
                <li>À configurer un serveur local sécurisé avec HTTPS.</li>
                <li>Les différences entre HTTP et HTTPS, ainsi que leurs implications pour la sécurité.</li>
            </ul>
        
            <h4>Défi :</h4>
            <ul>
                <li>Comparez la navigation sur un site HTTP et HTTPS pour observer les différences.</li>
                <li>Essayez d’intercepter les requêtes d’un site HTTP avec un outil comme Wireshark.</li>
            </ul>
        
            <h3>5. Discussion et Questions (20 min)</h3>
        
            <h4>Questions de Réflexion :</h4>
            <ul>
                <li>Pourquoi est-il risqué de naviguer sur un site HTTP non sécurisé ?</li>
                <li>Quels sont les avantages d’implémenter HTTPS sur un site Web ?</li>
                <li>Quelles autres mesures de sécurité pourraient être utilisées en complément de HTTPS ?</li>
            </ul>
        
            <h3>Conclusion :</h3>
            <p>
                À la fin de cette séance, les élèves auront une 
compréhension claire des protocoles de sécurité SSL/TLS et HTTPS. Ils 
auront appris :
            </p>
            <ul>
                <li>Les principes de base de SSL/TLS et leur fonctionnement.</li>
                <li>Les avantages de HTTPS par rapport à HTTP.</li>
                <li>À analyser des certificats SSL/TLS et à configurer un site local sécurisé.</li>
            </ul>
            <p>Ces connaissances sont essentielles pour comprendre 
comment protéger les communications sur Internet et les intégrer dans 
des projets futurs.</p>
        </section>