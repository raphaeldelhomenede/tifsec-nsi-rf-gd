<section id="session80" class="content-section">
            <h2>Séance 80 : Création et Gestion des Tokens d’Authentification</h2>

            <h3>Objectif Global :</h3>
            <p>
                Cette séance a pour but de comprendre ce que sont les <strong>tokens d’authentification</strong>, comment ils fonctionnent et comment les utiliser pour sécuriser une application.
                Nous allons explorer l’authentification basée sur des tokens, notamment avec le standard <strong>JWT (JSON Web Token)</strong>.
            </p>
        
            <h3>1. Introduction aux Tokens d’Authentification</h3>
        
            <h4>Qu’est-ce qu’un Token d’Authentification ?</h4>
            <p>
                Un <strong>token d’authentification</strong> est une chaîne de caractères générée pour prouver l’identité d’un utilisateur lors de la connexion à une application.
                Une fois généré, le token est envoyé au client, qui l’utilise pour accéder aux ressources sécurisées sans avoir à s’authentifier à chaque requête.
            </p>
        
            <h4>Pourquoi Utiliser des Tokens ?</h4>
            <ul>
                <li><strong>Stateless :</strong> Contrairement aux sessions classiques, le serveur ne stocke pas d’état de connexion.</li>
                <li><strong>Sécurisé :</strong> Un token est signé et ne peut pas être modifié sans la clé de signature.</li>
                <li><strong>Facilité d’intégration :</strong> Utilisé par les API REST, le token permet une authentification entre services.</li>
            </ul>
        
            <h4>Exemples d’Utilisation :</h4>
            <ul>
                <li>Authentification des utilisateurs sur une API.</li>
                <li>Gestion des sessions sans cookies.</li>
                <li>Autorisation d’accès aux ressources sécurisées.</li>
            </ul>
        
            <h3>2. Introduction à JSON Web Token (JWT)</h3>
        
            <h4>Qu’est-ce qu’un JWT ?</h4>
            <p>
                Le <strong>JSON Web Token (JWT)</strong> est un format de token sécurisé utilisé pour l’authentification et l’échange d’informations entre deux parties.
                Il est composé de trois parties encodées en <code>base64</code> :
            </p>
            <ul>
                <li><strong>Header :</strong> Contient le type de token et l’algorithme de signature.</li>
                <li><strong>Payload :</strong> Contient les informations de l’utilisateur.</li>
                <li><strong>Signature :</strong> Vérifie l’intégrité du token.</li>
            </ul>
        
            <h4>Schéma d’un JWT :</h4>
            <pre><code>
        eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9  // Header
        .
        eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFsaWNlIiwiaWF0IjoxNTE2MjM5MDIyfQ  // Payload
        .
        SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c  // Signature
            </code></pre>
        
            <h4>Exemple de Payload :</h4>
            <pre><code class="json">
        {
            "sub": "1234567890",
            "name": "Alice",
            "iat": 1516239022
        }
            </code></pre>
        
            <h3>3. Implémentation d’un Système d’Authentification avec JWT (40 min)</h3>
        
            <h4>Installation des Bibliothèques :</h4>
            <p>Nous allons utiliser <code>pyjwt</code> pour générer et valider des JWT en Python.</p>
            <pre><code class="bash">
        pip install pyjwt
            </code></pre>
        
            <h4>Génération d’un JWT :</h4>
            <pre><code class="python">
        import jwt
        import datetime
        
        SECRET_KEY = "supersecret"
        
        def generer_token(utilisateur):
            """Génère un token JWT pour un utilisateur"""
            expiration = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
            payload = {
                "sub": utilisateur,
                "exp": expiration,
                "iat": datetime.datetime.utcnow()
            }
            token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
            return token
        
        # Génération d’un token pour Alice
        token = generer_token("alice@example.com")
        print("Token JWT :", token)
            </code></pre>
        
            <h4>Vérification et Décodage d’un JWT :</h4>
            <pre><code class="python">
        def verifier_token(token):
            """Vérifie et décode un token JWT"""
            try:
                payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
                return payload
            except jwt.ExpiredSignatureError:
                return "Erreur : Token expiré"
            except jwt.InvalidTokenError:
                return "Erreur : Token invalide"
        
        # Vérification du token
        print(verifier_token(token))
            </code></pre>
        
            <h3>4. Sécurisation et Bonnes Pratiques (30 min)</h3>
        
            <h4>1. Ne Jamais Stocker un Token en Clair</h4>
            <p>Les tokens doivent être stockés de manière sécurisée, par exemple :</p>
            <ul>
                <li>Sur le client : dans <code>localStorage</code> (si HTTPS) ou via un cookie sécurisé.</li>
                <li>Sur le serveur : uniquement la clé secrète.</li>
            </ul>
        
            <h4>2. Mettre une Expiration aux Tokens</h4>
            <p>
                Pour limiter les risques de vol de tokens, on définit une durée de vie courte (ex. 1 heure), et on utilise des tokens de rafraîchissement (<strong>refresh tokens</strong>) pour prolonger l’accès.
            </p>
        
            <h4>3. Signer les Tokens avec une Clé Sécurisée</h4>
            <p>Utilisez des clés robustes et changez-les régulièrement.</p>
        
            <h3>5. Comparaison JWT vs Session Classique</h3>
        
            <table border="1" cellpadding="5">
                <tr>
                    <th>Critères</th>
                    <th>JWT</th>
                    <th>Session classique</th>
                </tr>
                <tr>
                    <td>Stockage</td>
                    <td>Sur le client</td>
                    <td>Sur le serveur</td>
                </tr>
                <tr>
                    <td>État du serveur</td>
                    <td>Stateless (sans état)</td>
                    <td>Stateful (avec état)</td>
                </tr>
                <tr>
                    <td>Scalabilité</td>
                    <td>Facile à déployer</td>
                    <td>Besoin de stocker des sessions</td>
                </tr>
                <tr>
                    <td>Sécurité</td>
                    <td>Risque si mal sécurisé</td>
                    <td>Plus contrôlé</td>
                </tr>
            </table>
        
            <h3>6. Exercice Pratique : Authentification avec Flask et JWT</h3>
        
            <h4>Installation :</h4>
            <pre><code class="bash">
        pip install flask flask-jwt-extended
            </code></pre>
        
            <h4>Implémentation :</h4>
            <pre><code class="python">
        from flask import Flask, jsonify
        from flask_jwt_extended import create_access_token, jwt_required, JWTManager
        
        app = Flask(__name__)
        app.config["JWT_SECRET_KEY"] = "supersecret"
        jwt = JWTManager(app)
        
        @app.route("/login", methods=["POST"])
        def login():
            token = create_access_token(identity="Alice")
            return jsonify(access_token=token)
        
        @app.route("/protected", methods=["GET"])
        @jwt_required()
        def protected():
            return jsonify(message="Accès autorisé")
        
        if __name__ == "__main__":
            app.run(debug=True)
            </code></pre>
        
            <h3>Conclusion</h3>
            <p>
                Nous avons appris comment fonctionnent les tokens d’authentification et comment les utiliser pour sécuriser une API.
            </p>
        </section>