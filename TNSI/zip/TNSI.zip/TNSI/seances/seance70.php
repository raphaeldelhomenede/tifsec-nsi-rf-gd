<section id="session70" class="content-section">
            <h2>Séance 70 : Introduction aux Architectures Matérielles, fonctionnement du Processeur et des Bus</h2>
        
            <h3>Objectif Global :</h3>
            <p>Les élèves découvriront les bases des architectures 
matérielles des ordinateurs. Ils apprendront à comprendre comment un 
ordinateur est structuré et comment ses composants interagissent pour 
exécuter des instructions. La séance mettra l’accent sur la structure de
 Von Neumann et ses implications pratiques.</p>
        
            <a href="https://eduscol.education.fr/document/7283/download" target="_blank" rel="noopener noreferrer">Ressources Eduscol</a>

            <h3>Plan de la Séance :</h3>
            <ul>
                <li><strong>Introduction aux architectures matérielles.</strong></li>
                <li><strong>Présentation de l'architecture de Von Neumann.</strong></li>
                <li><strong>Principaux composants matériels d’un ordinateur.</strong></li>
                <li><strong>Étude de cas : Cycle d’exécution d’une instruction.</strong></li>
                <li><strong>Atelier pratique : Simulation du fonctionnement matériel.</strong></li>
            </ul>
        
            <h3>1. Introduction aux Architectures Matérielles (20 min)</h3>
        
            <h4>Qu’est-ce qu’une architecture matérielle ?</h4>
            <p>
                Une architecture matérielle définit l’organisation des 
composants physiques (matériel) d’un ordinateur et la manière dont ces 
composants interagissent pour exécuter des programmes. Elle est composée
 de plusieurs parties principales, telles que :
            </p>
            <ul>
                <li>Le processeur (CPU).</li>
                <li>La mémoire (RAM, ROM, etc.).</li>
                <li>Les périphériques d’entrée et de sortie.</li>
                <li>Les bus (chemins de communication entre les composants).</li>
            </ul>
        
            <h4>Pourquoi est-ce important ?</h4>
            <p>
                Comprendre les architectures matérielles permet de :
            </p>
            <ul>
                <li>Savoir comment les programmes interagissent avec le matériel.</li>
                <li>Optimiser les performances des applications.</li>
                <li>Résoudre des problèmes liés au matériel et au logiciel.</li>
            </ul>
        
            <h3>2. Présentation de l'Architecture de Von Neumann (30 min)</h3>
        
            <h4>Concept clé :</h4>
            <p>
                L’architecture de Von Neumann est un modèle de base pour
 les ordinateurs modernes. Elle repose sur l’idée que les programmes et 
les données sont stockés dans une même mémoire accessible au processeur.
            </p>
        
            <h4>Structure de Von Neumann :</h4>
            <p>Voici les composants principaux :</p>
            <ul>
                <li><strong>Unité de traitement :</strong> Inclut l’Unité de Contrôle (UC) et l’Unité Arithmétique et Logique (ALU).</li>
                <li><strong>Mémoire :</strong> Stocke les programmes et les données.</li>
                <li><strong>Entrées/Sorties :</strong> Permettent la communication avec l’extérieur (clavier, écran, etc.).</li>
                <li><strong>Bus :</strong> Moyen de communication entre les composants.</li>
            </ul>
        
            <h4>Schéma de Von Neumann :</h4>
            <pre><code>
            Entrées  ---&gt;  Processeur  ---&gt;  Sorties
                               |
                          Mémoire
            </code></pre>
        
            <h4>Limitation principale :</h4>
            <p>
                Le "goulot d’étranglement de Von Neumann" : le 
processeur doit attendre que la mémoire transfère les instructions et 
les données, ce qui ralentit les performances.
            </p>
        
            <h3>3. Principaux Composants Matériels (30 min)</h3>
        
            <h4>1. Processeur (CPU) :</h4>
            <ul>
                <li><strong>Unité de Contrôle (UC) :</strong> Gère l’exécution des instructions.</li>
                <li><strong>Unité Arithmétique et Logique (ALU) :</strong> Effectue les calculs et les opérations logiques.</li>
            </ul>
        
            <h4>2. Mémoire :</h4>
            <ul>
                <li><strong>RAM :</strong> Mémoire volatile utilisée pour stocker les données et instructions en cours d’utilisation.</li>
                <li><strong>ROM :</strong> Mémoire non volatile contenant des instructions permanentes.</li>
                <li><strong>Mémoire cache :</strong> Mémoire rapide pour stocker des données fréquemment utilisées.</li>
            </ul>
        
            <h4>3. Périphériques :</h4>
            <ul>
                <li><strong>Entrée :</strong> Clavier, souris, capteurs.</li>
                <li><strong>Sortie :</strong> Écran, imprimante, haut-parleurs.</li>
            </ul>
        
            <h4>4. Bus :</h4>
            <ul>
                <li><strong>Bus de données :</strong> Transporte les données.</li>
                <li><strong>Bus d’adresse :</strong> Indique où les données doivent être envoyées.</li>
                <li><strong>Bus de contrôle :</strong> Coordonne les opérations entre les composants.</li>
            </ul>
        
            <h3>4. Étude de Cas : Cycle d’Exécution d’une Instruction (20 min)</h3>
        
            <h4>Cycle de base :</h4>
            <p>
                Une instruction dans un ordinateur suit trois étapes principales :
            </p>
            <ol>
                <li><strong>Fetch :</strong> L’unité de contrôle récupère l’instruction depuis la mémoire.</li>
                <li><strong>Decode :</strong> L’instruction est déchiffrée pour déterminer l’opération à effectuer.</li>
                <li><strong>Execute :</strong> L’ALU exécute l’instruction.</li>
            </ol>
        
            <h4>Exemple d’une addition :</h4>
            <p>Considérons une instruction pour additionner deux nombres stockés en mémoire :</p>
            <ul>
                <li><strong>Fetch :</strong> Récupérer l’instruction "ajouter A et B".</li>
                <li><strong>Decode :</strong> Déchiffrer l’instruction pour savoir que c’est une addition.</li>
                <li><strong>Execute :</strong> Effectuer l’opération A + B et stocker le résultat.</li>
            </ul>
        
            <h3>5. Atelier Pratique : Simulation (20 min)</h3>
        
            <h4>Objectif :</h4>
            <p>
                Les élèves simuleront le fonctionnement d’une 
architecture matérielle en utilisant des listes et des fonctions en 
Python.
            </p>
        
            <h4>Exercice :</h4>
            <p>Écrivez un programme qui simule l’exécution d’instructions dans un modèle simplifié de Von Neumann.</p>
        
            <h4>Exemple de Code :</h4>
            <pre><code class="python">
        # Simulation de l'architecture de Von Neumann
        memoire = [10, 20, "ADD", 0]  # Instructions et données
        accumulateur = 0  # Stockage temporaire des calculs
        
        def fetch(memoire, pc):
            """Récupère l'instruction à l'adresse PC"""
            return memoire[pc]
        
        def decode(instruction):
            """Décode l'instruction"""
            return instruction
        
        def execute(instruction, memoire):
            """Exécute l'instruction"""
            global accumulateur
            if instruction == "ADD":
                accumulateur = memoire[0] + memoire[1]
                memoire[3] = accumulateur
            return accumulateur
        
        # Cycle d'exécution
        pc = 2  # Pointeur de l'instruction actuelle
        instruction = fetch(memoire, pc)
        decoded_instruction = decode(instruction)
        resultat = execute(decoded_instruction, memoire)
        
        print(f"Résultat de l'addition : {resultat}")  # 30
            </code></pre>
        
            <h4>Questions pour les élèves :</h4>
            <ul>
                <li>Quels composants matériels sont simulés dans ce programme ?</li>
                <li>Comment améliorer le programme pour inclure plusieurs instructions ?</li>
            </ul>
            <hr>
            <h2>Fonctionnement du Processeur et des Bus</h2>
        
            <h3>Objectif Global :</h3>
            <p>
                Comprendre le fonctionnement interne d’un processeur, 
son interaction avec les bus (bus de données, bus d’adresse, bus de 
contrôle) et leur rôle dans l’exécution des instructions. Cette séance 
vise à fournir une base théorique solide complétée par des exemples 
pratiques et des démonstrations simples.
            </p>
        
            <h3>Introduction :</h3>
            <p>
                Le processeur (CPU - Central Processing Unit) est 
souvent décrit comme le cerveau de l'ordinateur. Il exécute les 
instructions des programmes en manipulant des données. Pour fonctionner 
efficacement, le processeur utilise les <strong>bus</strong>, qui sont des voies de communication permettant l’échange d’informations avec la mémoire et les périphériques.
            </p>
        
            <h4>Les principaux composants du processeur :</h4>
            <ul>
                <li><strong>Unité de contrôle :</strong> Elle dirige le flux des données et des instructions à travers le processeur.</li>
                <li><strong>Unité arithmétique et logique (ALU) :</strong> Elle exécute les calculs mathématiques et les comparaisons logiques.</li>
                <li><strong>Registres :</strong> Ce sont de petites mémoires ultra-rapides utilisées pour stocker temporairement des données et des instructions.</li>
            </ul>
        
            <h3>Les Bus : Rôles et Types</h3>
            <p>
                Les bus sont des ensembles de lignes de communication 
utilisées pour transmettre des données, des adresses et des signaux de 
contrôle entre les composants de l’ordinateur.
            </p>
        
            <h4>Les trois principaux types de bus :</h4>
            <ul>
                <li><strong>Bus de données :</strong> Transporte les données entre le processeur, la mémoire et les périphériques.</li>
                <li><strong>Bus d’adresse :</strong> Indique l’adresse mémoire ou le périphérique à utiliser pour une opération.</li>
                <li><strong>Bus de contrôle :</strong> Transporte les signaux de commande (lecture, écriture, interruption, etc.).</li>
            </ul>
        
            <h4>Illustration :</h4>
            <p>Voici un schéma simplifié d’un système avec un processeur, une mémoire et des bus :</p>
            <pre><code>
        +-------------+       +-------------------+
        |             |       |                   |
        | Processeur  |=======|       Mémoire     |
        |             |       |                   |
        +-------------+       +-------------------+
           ||  ||  ||
           ||  ||  ||    Bus de données
           ||  ||  ||
           ||  ||       Bus d’adresse
           ||           Bus de contrôle
            </code></pre>
        
            <h3>Étape 1 : Comprendre le Cycle Machine (30 min)</h3>
            <p>
                Le cycle machine est le processus par lequel le 
processeur exécute les instructions. Il est composé de trois phases 
principales :
            </p>
            <ul>
                <li><strong>Phase 1 : Récupération (Fetch)</strong> – Le processeur récupère l’instruction depuis la mémoire.</li>
                <li><strong>Phase 2 : Décodage (Decode)</strong> – L’instruction est décomposée pour comprendre l’opération à effectuer.</li>
                <li><strong>Phase 3 : Exécution (Execute)</strong> – Le processeur exécute l’instruction (calcul, transfert de données, etc.).</li>
            </ul>
        
            <h4>Exemple Pratique :</h4>
            <p>
                Imaginez une instruction simple : charger la valeur 42 
dans un registre. Voici comment le processeur traite cette instruction :
            </p>
            <ol>
                <li><strong>Fetch :</strong> L’instruction est récupérée de la mémoire et placée dans un registre d’instruction.</li>
                <li><strong>Decode :</strong> L’unité de contrôle identifie qu’il s’agit d’une opération de chargement.</li>
                <li><strong>Execute :</strong> La valeur 42 est transférée dans le registre spécifié.</li>
            </ol>
        
            <h3>Étape 2 : Interaction entre Processeur et Bus (40 min)</h3>
        
            <h4>Exemple d’interaction :</h4>
            <p>
                Le processeur souhaite lire une valeur située à une 
adresse mémoire spécifique. Voici les étapes impliquant les bus :
            </p>
            <ol>
                <li><strong>Bus d’adresse :</strong> Le processeur place l’adresse mémoire sur le bus d’adresse.</li>
                <li><strong>Bus de contrôle :</strong> Le processeur envoie un signal de lecture (READ).</li>
                <li><strong>Bus de données :</strong> La mémoire renvoie la valeur demandée au processeur via le bus de données.</li>
            </ol>
        
            <h4>Exercice :</h4>
            <p>
                Simulez les étapes ci-dessus à l’aide de pseudo-code ou de schémas simples. Par exemple :
            </p>
            <pre><code class="python">
        # Simulation de lecture mémoire
        adresse = 0x10A  # Adresse mémoire
        print(f"Placer l'adresse {adresse} sur le bus d'adresse.")
        print("Envoyer un signal READ sur le bus de contrôle.")
        valeur = memoire[adresse]  # Lecture dans la mémoire simulée
        print(f"La valeur {valeur} est reçue via le bus de données.")
            </code></pre>
        
            <h3>Étape 3 : Défi Pratique (30 min)</h3>
        
            <h4>Exercice :</h4>
            <p>
                Créez une simulation simplifiée d’un processeur, de la mémoire et des bus. Les étapes doivent inclure :
            </p>
            <ul>
                <li>Récupération d’une instruction depuis la mémoire.</li>
                <li>Décodage de l’instruction.</li>
                <li>Exécution d’une opération simple (addition, soustraction, etc.).</li>
            </ul>
        
            <h4>Exemple de Structure Python :</h4>
            <pre><code class="python">
        class Memoire:
            def __init__(self):
                self.stockage = {0x10A: 42, 0x10B: 18}  # Exemple de mémoire
        
            def lire(self, adresse):
                return self.stockage.get(adresse, 0)
        
        class Processeur:
            def __init__(self, memoire):
                self.memoire = memoire
                self.registre = 0  # Registre unique pour cet exemple
        
            def executer(self, adresse):
                print(f"Placer l'adresse {adresse} sur le bus d'adresse.")
                valeur = self.memoire.lire(adresse)
                print(f"Lire la valeur {valeur} via le bus de données.")
                self.registre = valeur
                print(f"Valeur {valeur} stockée dans le registre.")
        
        # Simulation
        memoire = Memoire()
        processeur = Processeur(memoire)
        
        processeur.executer(0x10A)  # Charge la valeur 42
        processeur.executer(0x10B)  # Charge la valeur 18
            </code></pre>
        
            <h3>Conclusion :</h3>
            <p>
                À la fin de cette séance, les élèves auront appris :
            </p>
            <ul>
                <li>Les rôles principaux du processeur (récupération, décodage, exécution).</li>
                <li>Comment les bus permettent la communication entre les composants d’un ordinateur.</li>
                <li>À simuler des interactions processeur-mémoire pour mieux comprendre leur fonctionnement.</li>
            </ul>
            <p>Ce cours constitue une base solide pour comprendre les architectures informatiques et leur fonctionnement interne.</p>
        </section>