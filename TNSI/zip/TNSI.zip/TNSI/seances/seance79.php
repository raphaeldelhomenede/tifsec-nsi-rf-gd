<section id="session79" class="content-section">
            <h2>Séance 79 : Utilisation des Algorithmes de Chiffrement dans les Applications Réseau</h2>

            <h3>Objectif Global :</h3>
            <p>
                Cette séance a pour but de comprendre le fonctionnement du chiffrement dans les applications réseau. 
                Nous allons étudier les principes du chiffrement **symétrique** et **asymétrique**, leurs différences, 
                et les appliquer dans des communications sécurisées en Python.
            </p>
        
            <h3>1. Introduction au Chiffrement</h3>
        
            <h4>Pourquoi Chiffrer les Communications Réseau ?</h4>
            <p>
                Les communications sur Internet peuvent être interceptées par des pirates informatiques. Le chiffrement permet de :
            </p>
            <ul>
                <li>Protéger la confidentialité des données.</li>
                <li>Garantir l’intégrité des messages échangés.</li>
                <li>Empêcher les attaques de type "Man-in-the-Middle".</li>
            </ul>
        
            <h3>2. Algorithmes de Chiffrement</h3>
        
            <h4>Chiffrement Symétrique</h4>
            <p>
                Le chiffrement symétrique utilise une <strong>clé unique</strong> pour chiffrer et déchiffrer un message. 
                L’expéditeur et le destinataire doivent tous deux posséder cette clé secrète.
            </p>
        
            <h4>Exemples d’algorithmes :</h4>
            <ul>
                <li><strong>AES (Advanced Encryption Standard)</strong> : Utilisé pour la plupart des communications sécurisées.</li>
                <li><strong>DES (Data Encryption Standard)</strong> : Ancien standard, aujourd’hui obsolète.</li>
                <li><strong>ChaCha20</strong> : Utilisé pour des performances élevées.</li>
            </ul>
        
            <h4>Avantages :</h4>
            <ul>
                <li>Rapide et efficace.</li>
                <li>Requiert peu de ressources.</li>
            </ul>
        
            <h4>Inconvénients :</h4>
            <ul>
                <li>La clé doit être partagée en toute sécurité.</li>
                <li>Si la clé est compromise, toutes les communications sont vulnérables.</li>
            </ul>
        
            <h4>Implémentation du Chiffrement Symétrique en Python</h4>
            <pre><code class="python">
        from cryptography.fernet import Fernet
        
        # Générer une clé secrète
        cle_secrete = Fernet.generate_key()
        cipher = Fernet(cle_secrete)
        
        # Chiffrement du message
        message = "Données confidentielles"
        message_chiffre = cipher.encrypt(message.encode())
        
        # Déchiffrement du message
        message_dechiffre = cipher.decrypt(message_chiffre).decode()
        
        print(f"Message original : {message}")
        print(f"Message chiffré : {message_chiffre}")
        print(f"Message déchiffré : {message_dechiffre}")
            </code></pre>
        
            <h3>3. Chiffrement Asymétrique</h3>
        
            <h4>Définition</h4>
            <p>
                Le chiffrement asymétrique utilise une **paire de clés** : 
                une clé publique pour chiffrer les messages et une clé privée pour les déchiffrer.
            </p>
        
            <h4>Exemples d’algorithmes :</h4>
            <ul>
                <li><strong>RSA (Rivest-Shamir-Adleman)</strong> : Utilisé pour le chiffrement des e-mails et SSL/TLS.</li>
                <li><strong>ECC (Elliptic Curve Cryptography)</strong> : Plus rapide et sécurisé pour les mobiles.</li>
            </ul>
        
            <h4>Avantages :</h4>
            <ul>
                <li>Permet un échange sécurisé sans partager une clé secrète.</li>
                <li>Utilisé pour les signatures numériques et l’authentification.</li>
            </ul>
        
            <h4>Inconvénients :</h4>
            <ul>
                <li>Plus lent que le chiffrement symétrique.</li>
                <li>Requiert des clés plus grandes pour une sécurité équivalente.</li>
            </ul>
        
            <h4>Implémentation du Chiffrement Asymétrique en Python</h4>
            <pre><code class="python">
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.primitives import hashes
        
        # Générer une paire de clés
        cle_privee = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        cle_publique = cle_privee.public_key()
        
        # Chiffrement avec la clé publique
        message = b"Message secret"
        message_chiffre = cle_publique.encrypt(
            message,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # Déchiffrement avec la clé privée
        message_dechiffre = cle_privee.decrypt(
            message_chiffre,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        print(f"Message chiffré : {message_chiffre}")
        print(f"Message déchiffré : {message_dechiffre.decode()}")
            </code></pre>
        
            <h3>4. Application : Communication Sécurisée en Réseau</h3>
        
            <h4>Scénario :</h4>
            <p>
                Un client envoie un message chiffré au serveur. Le serveur déchiffre et répond.
            </p>
        
            <h4>Code du Serveur :</h4>
            <pre><code class="python">
        import socket
        from cryptography.fernet import Fernet
        
        # Générer une clé
        cle_secrete = Fernet.generate_key()
        cipher = Fernet(cle_secrete)
        
        serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        serveur.bind(("127.0.0.1", 12345))
        serveur.listen(1)
        
        print("Serveur en attente...")
        conn, addr = serveur.accept()
        message_recu = conn.recv(1024)
        message_dechiffre = cipher.decrypt(message_recu).decode()
        
        print(f"Message reçu : {message_dechiffre}")
        
        conn.sendall(cipher.encrypt("Réponse sécurisée".encode()))
        conn.close()
        serveur.close()
            </code></pre>
        
            <h4>Code du Client :</h4>
            <pre><code class="python">
        import socket
        from cryptography.fernet import Fernet
        
        # Récupérer la clé
        cipher = Fernet(cle_secrete)
        
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(("127.0.0.1", 12345))
        
        message = "Données sécurisées"
        client.sendall(cipher.encrypt(message.encode()))
        
        reponse_chiffree = client.recv(1024)
        reponse = cipher.decrypt(reponse_chiffree).decode()
        
        print(f"Réponse du serveur : {reponse}")
        
        client.close()
            </code></pre>
        
            <h3>Conclusion</h3>
            <p>
                Nous avons exploré les concepts du chiffrement et leur application aux communications réseau.
                Le chiffrement symétrique est rapide, tandis que l’asymétrique permet des échanges sécurisés sans partage de clé secrète.
            </p>
        </section>