<section id="session2" class="content-section">
            <h2 style="margin-top: 30px; margin-bottom: 20px;">Séance 2 : Pratique - Implémentation d’une Fonction Récursive pour Calculer une Suite Mathématique</h2>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Objectif :</h3>
            <ul>
                <li>Comprendre et implémenter une fonction récursive.</li>
                <li>Appliquer la récursivité pour résoudre un problème pratique, inspiré des mécanismes de jeux vidéo.</li>
            </ul>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Contexte :</h3>
            <p>Dans un jeu vidéo, un personnage accumule des points 
d'attaque supplémentaires au fil du temps à chaque coup porté à 
l'ennemi, mais les points bonus diminuent à chaque itération jusqu'à 
atteindre un seuil minimum. Cela peut être représenté par une suite 
mathématique où le bonus d'attaque à chaque coup est calculé 
récursivement.</p>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">Exemple Concret :</h4>
            <p>Le personnage gagne 10 points d'attaque lors du premier 
coup, puis le bonus diminue de 1 point à chaque coup suivant. Cela forme
 une série mathématique décrite par :</p>
            <pre><code>Attaque(n) = Attaque(n−1) + (bonus initial − n)</code></pre>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Étape 1 : Introduction à la Récursivité</h3>
            <p><strong>Concept de la récursivité :</strong></p>
            <p>Une fonction récursive s'appelle elle-même pour résoudre 
un problème plus simple à chaque étape, jusqu'à atteindre une condition 
de fin (ou cas de base).</p>
            
            <h4 style="margin-top: 20px; margin-bottom: 20px;">Exemple théorique :</h4>
            <p>Calcul de la suite de Fibonacci ou de la factorielle pour illustrer la récursivité.</p>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Étape 2 : Implémentation d'une Fonction Récursive</h3>
            <p><strong>Problème :</strong> Dans le jeu, à chaque 
attaque, le personnage accumule des points bonus. Le premier coup ajoute
 10 points, puis chaque coup suivant ajoute 1 point de moins que le 
précédent jusqu'à atteindre 0. L'objectif est de calculer combien de 
points d'attaque sont accumulés après un certain nombre de coups.</p>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">Fonction récursive pour calculer le bonus d'attaque :</h4>
            <pre><code>
    def attaque_bonus(n):
        # Cas de base : quand le bonus atteint 0
        if n == 0:
            return 0
        else:
            # Récursion : bonus initial (10) - n + bonus précédent
            return (10 - n) + attaque_bonus(n - 1)
    
    # Exemple d'utilisation :
    coups = 5  # Le personnage donne 5 coups
    total_bonus = attaque_bonus(coups)
    print(f"Le total des points d'attaque après {coups} coups est de : {total_bonus}")
            </code></pre>
        
            <p><strong>Explication :</strong></p>
            <ul>
                <li>La fonction se base sur un cas de base où aucun coup n'est porté (0 bonus).</li>
                <li>À chaque appel récursif, le nombre de coups diminue de 1, et le bonus est calculé en fonction du coup précédent.</li>
                <li>Le bonus d’attaque diminue jusqu'à ce que la fonction atteigne le cas de base (0).</li>
            </ul>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Étape 3 : Étendre la Fonctionnalité</h3>
            <p>Amélioration du jeu : Proposer aux élèves d’ajouter des conditions supplémentaires :</p>
            <ul>
                <li>Le bonus ne peut pas descendre en dessous de 0.</li>
                <li>Ajouter un effet multiplicateur pour chaque coup critique (par exemple, multiplier par 2 si c’est un coup critique).</li>
            </ul>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">Exemple d’amélioration :</h4>
            <pre><code>
    def attaque_bonus(n, critique=False):
        if n == 0:
            return 0
        else:
            bonus = (10 - n)  # Le bonus diminue avec chaque coup
            if critique and n % 3 == 0:
                bonus *= 2  # Coup critique tous les 3 coups
            return bonus + attaque_bonus(n - 1, critique)
    
    # Exemple d'utilisation :
    coups = 5
    total_bonus = attaque_bonus(coups, critique=True)
    print(f"Le total des points d'attaque avec coups critiques est de : {total_bonus}")
            </code></pre>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Étape 4 : Exercices Pratiques</h3>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">1. Calcul d'attaque simple :</h4>
            <p>Modifier le nombre de coups portés et afficher le total des points d'attaque.</p>
            <p><strong>Exercice :</strong> Demander aux élèves de tester avec 3, 5 et 10 coups pour voir comment la récursivité calcule le total.</p>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">2. Scénario avancé : Combats de boss :</h4>
            <p>Simuler un combat contre un boss où chaque coup critique donne des points bonus supplémentaires.</p>
            <p><strong>Exercice :</strong> Les élèves doivent 
implémenter une version du programme où tous les 5 coups, le personnage 
inflige un coup critique (multiplication du bonus par 3).</p>
        
            <h3 style="margin-top: 30px; margin-bottom: 20px;">Conclusion</h3>
            <p><strong>Retour sur la notion de récursivité :</strong></p>
            <ul>
                <li><strong>Avantage :</strong> La récursivité permet de simplifier des calculs répétitifs en divisant le problème en sous-problèmes.</li>
                <li><strong>Inconvénient :</strong> Elle peut entraîner des problèmes de performance si elle est mal utilisée (pile d'appels récursifs trop grande).</li>
            </ul>
        
            <p><strong>Lien avec le jeu vidéo :</strong> La récursivité 
est un outil puissant pour modéliser des mécanismes de jeu où des 
actions répétitives évoluent à chaque itération, comme la gestion des 
dégâts dans les combats.</p>
        
            <h4 style="margin-top: 20px; margin-bottom: 20px;">Exercice final :</h4>
            <p>Les élèves devront créer une version améliorée de la 
fonction récursive qui inclut plusieurs types de coups (coup normal, 
coup critique, coup spécial) avec des bonus différents et implémenter 
une stratégie pour battre un boss avec un nombre limité de coups.</p>
        </section>