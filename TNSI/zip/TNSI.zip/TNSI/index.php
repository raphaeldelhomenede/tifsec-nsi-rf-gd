<?php
$json3 = file_get_contents('https://raphaeldelhomenede.github.io/tifsec-nsi-rf-gd/TNSI/seances.json');
$seances_data3 = json_decode($json3, true);
$sessions = $seances_data3[6][3][0][0][1];

$sessions = array_merge($sessions, [
    // 'programme1' => 'Programme potentiel Jeux vidéos',
    // 'programme2' => 'Programme potentiel Application de gestion de budget',
    // 'programme3' => 'Programme potentiel Application de gestion de mangas',
    // 'programme4' => 'Programme potentiel Site Web',
    
    // Ajoutez ici toutes les autres séances...
]);

$sessions1 = $seances_data3[5];

if ($_SERVER['HTTP_HOST'] == 'localhost') {
    $today11 = date("d/m/Y H:i:s");
    $today11dmy = substr($today11, 0, 10);
} elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
    $today11 = date("d/m/Y H:i:s", strtotime("+6 hours"));
    $today11dmy = substr($today11, 0, 10);
}

// Gestion de la séance sélectionnée
$session_actuelle = $_GET['session'] ?? 'calendar';
$session_titre = $sessions1[$session_actuelle] ?? '';
$seances = $seances_data3[0];
foreach ($seances_data3[3][0] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances de la Toussaint","id" => ""];}
$seances = array_merge($seances, $seances_data3[1]);
    foreach ($seances_data3[3][1][0] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "holiday","titre" => "Noël","id" => "calendar"];}
    foreach ($seances_data3[3][1][1] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances de Noël","id" => "calendar"];}
    foreach ($seances_data3[3][1][2] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "holiday","titre" => "Jour de l'An","id" => "calendar"];}
    foreach ($seances_data3[3][1][3] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances de Noël","id" => "calendar"];}
$seances = array_merge($seances, $seances_data3[2]);
    foreach ($seances_data3[3][2] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances d'hiver","id" => "calendar"];}
$seances = array_merge($seances, $seances_data3[4]);
$seances = array_merge($seances, [
    ["date" => "16/04/2025", "titre" => "Séance 79 : Introduction aux protocoles réseau (TCP, UDP, IP) et modèle OSI", "id" => "seance79"],
    ["date" => "17/04/2025", "titre" => "Séance 80 : Les adresses IP et le routage", "id" => "seance80"],
    ["date" => "18/04/2025", "titre" => "Séance 81 : Protocole HTTP et API REST", "id" => "seance81"]]);
    foreach ($seances_data3[3][3][0] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances de printemps","id" => "calendar"];}
    foreach ($seances_data3[3][3][1] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "holiday","titre" => "Fête du Travail","id" => "calendar"];}
    foreach ($seances_data3[3][3][2] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances de printemps","id" => "calendar"];}

$seances = array_merge($seances, [
    ["date" => "07/05/2025", "titre" => "Séance 82 : Modèle Client-Serveur et P2P (Peer-to-Peer)", "id" => "seance82"],
    ["date" => "08/05/2025", "titre" => "Victoire 1945", "id" => "calendar", "class" => "holiday"],
    ["date" => "09/05/2025", "titre" => "Séance 83 : Pont", "id" => "seance83"],
    ["date" => "14/05/2025", "titre" => "Séance 84 : Introduction aux Processus", "id" => "seance84"],
    ["date" => "15/05/2025", "titre" => "Séance 85 : États d’un processus & gestion du CPU", "id" => "seance85"],
    ["date" => "16/05/2025", "titre" => "Séance 86 : Commandes avancées de gestion de processus", "id" => "seance86"],
    ["date" => "21/05/2025", "titre" => "Séance à définir", "id" => "seance87"],
    ["date" => "22/05/2025", "titre" => "Séance à définir", "id" => "seance88"],
    ["date" => "23/05/2025", "titre" => "Séance à définir", "id" => "seance89"],
    ["date" => "28/05/2025", "titre" => "Séance à définir", "id" => "seance90"],
    ["date" => "29/05/2025", "titre" => "Ascension", "id" => "calendar", "class" => "holiday"],
    ["date" => "30/05/2025", "titre" => "Séance à définir", "id" => "seance91"],
    ["date" => "04/06/2025", "titre" => "Séance à définir", "id" => "seance92"],
    ["date" => "05/06/2025", "titre" => "Séance à définir", "id" => "seance93"],
    ["date" => "06/06/2025", "titre" => "Séance à définir", "id" => "seance94"],
    ["date" => "11/06/2025", "titre" => "Séance à définir", "id" => "seance95"],
    ["date" => "12/06/2025", "titre" => "Séance à définir", "id" => "seance96"],
    ["date" => "13/06/2025", "titre" => "Séance à définir", "id" => "seance97"],
    ["date" => "18/06/2025", "titre" => "Séance à définir", "id" => "seance98"],
    ["date" => "19/06/2025", "titre" => "Séance à définir", "id" => "seance99"],
    ["date" => "20/06/2025", "titre" => "Séance à définir", "id" => "seance100"],
    ["date" => "25/06/2025", "titre" => "Séance à définir", "id" => "seance101"],
    ["date" => "26/06/2025", "titre" => "Séance à définir", "id" => "seance102"],
    ["date" => "27/06/2025", "titre" => "Séance à définir", "id" => "seance103"],
    ["date" => "02/07/2025", "titre" => "Séance à définir", "id" => "seance104"],
    ["date" => "03/07/2025", "titre" => "Séance à définir", "id" => "seance105"],
    ["date" => "04/07/2025", "titre" => "Séance à définir", "id" => "seance106"],
]);
    foreach ($seances_data3[3][4] as $gtjdydtyk895) {$seances[] = ["date" => $gtjdydtyk895,"class" => "vacation","titre" => "Vacances d'été" ,"id" => "calendar"];}

$seanceCount = count($seances);
?>
<!DOCTYPE html>
<html lang="fr"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programme NSI Tle</title>
    <?php
    $json1 = file_get_contents('https://raphaeldelhomenede.github.io/tifsec-nsi-rf-gd/TNSI/index-data.json');
    $fonts1 = json_decode($json1, true);
    $font1 = isset($_GET['font']) ? $_GET['font'] : 'default';
    $cssLink1 = isset($fonts1[$font1]) ? $fonts1[$font1]['linkcss'] : $fonts1['default']['linkcss'];
    ?>
    <link rel="stylesheet" href="<?php echo htmlspecialchars($cssLink1); ?>">
    <?php
    if (isset($_GET['background']) && (!isset($_GET['session']) || $_GET['session'] !== 'Background')) {
        header("Location: ?session=Background&background=" . urlencode($_GET["background"]));
        exit();
    }
    ?>
</head>
<body>
    <header>
        <h1>Programme NSI Tle</h1>
    </header>
    
    <aside>
        <button class="hamburger" onclick="toggleMenu()">☰ Menu</button>
        <nav id="session-nav">
            <ul>
                <?php foreach ($sessions as $key5522 => $title) : ?>
                <li>
                <a href="<?php 
                    if ($_SERVER['HTTP_HOST'] == 'localhost') {
                        if ($key5522 == 'calendar') {
                            echo 'http://' . $_SERVER['HTTP_HOST'] . '/document/TNSI';
                        } else {
                            echo 'http://' . $_SERVER['HTTP_HOST'] . '/document/TNSI/?session=' . $key5522;
                        }
                    } elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
                        if ($key5522 == 'calendar') {
                            $url1 = $fonts1[$font1]['link2'];
                            echo 'https://' . $_SERVER['HTTP_HOST'] . '/TNSI' . $fonts1[$font1]['link2'];
                        } else {
                            $url1 = $fonts1[$font1]['link3'];
                            echo 'https://' . $_SERVER['HTTP_HOST'] . '/TNSI/?session=' . $key5522 . $fonts1[$font1]['link3'];
                        }
                    }
            ?>" class="<?= ($key5522 == $session_actuelle) ? 'active' : '' ?>">
                <?= $title ?>
            </a>
                </li>
            <?php endforeach; ?>
            </ul>
        </nav>
    </aside>
    
    <main>
        <h2><?= htmlspecialchars($session_titre) ?></h2>
        <?php if ($session_actuelle == 'calendar') : ?>
            <table class="calendar">
                <thead>
                    <tr>
                        <?php
                        foreach ($seances_data3[6][1] as $rgh1665) {
                            echo "<th>" . htmlspecialchars($rgh1665) . "</th>";
                        }
                        ?>
                    </tr>
                </thead>
                <tbody id="calendar-body">
                <?php
                for ($i82229 = 0; $i82229 < $seanceCount; $i82229 += 3) {
                    echo '<tr>';
                    
                    // Afficher jusqu'à 3 séances sur la même ligne
                    for ($j82229 = 0; $j82229 < 3; $j82229++) {
                        if ($i82229 + $j82229 < $seanceCount) {
                            $seance = $seances[$i82229 + $j82229];
                            $class = isset($seance['class']) ? 'class="' . $seance['class'] . '"' : '';
                            
                            // Vérifier si c'est un jour férié ou des vacances
                            $joursFeries22582 = $seances_data3[3][5];
                
                            if (in_array($seance["date"], $joursFeries22582)) {
                                $todayClass11 = ($seance['date'] === $today11dmy) ? 'today' : '';
                                echo "<td id='".$seance['date']."' class='" . (($seance['date'] === $today11dmy) ? $todayClass11 : $seance['class']) . "'>{$seance['date']}</td>";
                                echo "<td class='" . (($seance['date'] === $today11dmy) ? $todayClass11 : $seance['class']) . "'>{$seance['titre']}</td>";
                            } else {
                                $todayClass11 = ($seance['date'] === $today11dmy) ? 'today' : '';
                                echo "<td id='".$seance['date']."' $class class='$todayClass11'>{$seance['date']}</td>";
                                echo "<td $class class='$todayClass11'><a href='?session={$seance["id"]}" . $fonts1[$font1]['link3'] . "'>{$seance["titre"]}</a></td>";
                            }
                        }
                    }
                    
                    echo '</tr>';
                }

                if (isset($_GET['session'])) {
                    $id = $_GET['session'];
                    $seance = array_filter($seances, fn($s14232) => $s14232["id"] === $id);
                }
                ?>
                </tbody>
            </table> <!--<?php echo $today11; echo ' '.$today11dmy; ?>-->
        <?php elseif (in_array($session_actuelle, array_keys($seances_data3[6][0]))) :
                echo $fonts1[$font1][$seances_data3[6][0][$session_actuelle]];
              elseif ($session_actuelle == 'revision') : ?>
            <a href="https://www.annabac.com/terminale-generale/numerique-et-sciences-informatiques-nsi" target="_blank" rel="noopener noreferrer">C'est ici pour réviser</a>
        <?php elseif (preg_match('/^seance(\d+)$/', $session_actuelle, $matches)) :
            $seance_num = intval($matches[1]);
            if ($seance_num < 87) {
                echo '<iframe src="https://raphaeldelhomenede.github.io/tifsec-nsi-rf-gd/TNSI/seances/seance' . $seance_num . '.html' . $fonts1[$font1]['link4'] . '" class="tifsec1" frameborder="0"></iframe>';
            } elseif ($seance_num >= 87 && $seance_num < 107) {
                echo "<h2>Séance en cours de construction</h2>";
            } else {
                $font_param12614684685 = isset($_GET['font']) ? "&font=" . urlencode($_GET['font']) : '';
                header("Location: https://tifsec.github.io/TNSI/?session=seance" . $seance_num . $font_param12614684685);
                exit();
            }
        elseif ($session_actuelle == 'toto') :
            require_once($fonts1[$font1]['toto1']);
        elseif (strpos($session_actuelle, "08/03") === 0) :
            header("Location: " . 
                ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http") . 
                "://" . $_SERVER['HTTP_HOST'] . 
                "/TNSI/?session=Joyeux-anniversaire"
            );
            exit;
        elseif ($session_actuelle == 'Joyeux-anniversaire') :
        ?>
        <div style="position: relative; width: 100%; height: 0; padding-bottom: 56.25%; /* ratio 16:9 */">
            <iframe src="https://www.youtube-nocookie.com/embed/HjXxvooa-0g?controls=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen style="position: absolute; top: -30px; left: -15px; width: 100%; height: 85%;"></iframe>
        </div>
        <?php
        elseif (in_array($session_actuelle, array_keys($seances_data3[6][2]))) :
            $variable242 = $seances_data3[6][2][$session_actuelle][$font1]; ?>
            <iframe src="<?= htmlspecialchars($variable242); ?>" class="tifsec1" frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen style="margin-left: -12px;">
            </iframe>
        <?php elseif (in_array($session_actuelle, array_keys($seances_data3[6][3][0][0][0]))) :
                header("Location: " . $seances_data3[6][3][0][0][0][$session_actuelle]);
                exit();
            elseif ($session_actuelle === "Background") :
            ?>
            <?php if ($_GET['background']) : ?>
                <style>
                main {
                    background-image: url(<?= $_GET['background'] ?>);
                    background-repeat: repeat-y;
                    background-size: 100% auto;
                    background-position: top center;
                    min-height: 100vh; /* Pour forcer à voir le fond */
                }
                </style>
            <?php
            endif; ?>
            <?php
            endif;
            ?>
    </main>

    <!-- <footer>
        <p>&copy; 2024 Programme NSI</p>
    </footer> -->
</body>
</html>
<script>
function toggleMenu() {
    const menu = document.getElementById("session-nav");
    menu.style.display = menu.style.display === "block" ? "none" : "block";
}
</script>
<?php
if ($session_actuelle == 'today') {
    if ($_SERVER['HTTP_HOST'] == 'localhost') {
        header("Location: " . $fonts1[$font1]['link6'][1][0] . $today11dmy . $fonts1[$font1]['link6'][1][1]);
        exit;
    }
    
    elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
        header("Location: " . $fonts1[$font1]['link6'][0][0] . $today11dmy . $fonts1[$font1]['link6'][0][1]);
        exit;
    }
}
function estDateValide($d16516) {
    return preg_match("/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/[0-9]{4}$/", $d16516);
}
if (estDateValide($session_actuelle)) {
    foreach ($seances as $seance) {
        if ($session_actuelle === $seance["date"]) {
            if ($_SERVER['HTTP_HOST'] == 'localhost') {
                header("Location: " . $fonts1[$font1]['link6'][1][0] . $seance["id"] . $fonts1[$font1]['link6'][1][1]);
                exit;
            }
            
            elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
                header("Location: " . $fonts1[$font1]['link6'][0][0] . $seance["id"] . $fonts1[$font1]['link6'][0][1]);
                exit;
            }
        }
    }
    if ($_SERVER['HTTP_HOST'] == 'localhost') {
        $font695846 = isset($_GET['font']) ? $_GET['font'] : null;
        header("Location: " . $fonts1[$font1]['link6'][1][0] . "toto" . $fonts1[$font1]['link6'][1][1]);
        exit;
    }
    
    elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
        $font695846 = isset($_GET['font']) ? $_GET['font'] : null;
        header("Location: " . $fonts1[$font1]['link6'][0][0] . "toto" . $fonts1[$font1]['link6'][0][1]);
        exit;
    }
}

if ($session_actuelle == 'id:today') {
    if ($_SERVER['HTTP_HOST'] == 'localhost') {
        header("Location: " . "http://localhost/document/TNSI/" . $fonts1[$font1]['link4'] . "#" . $today11dmy);
        exit;
    }
    
    elseif ($_SERVER['HTTP_HOST'] == 'tifsec-nsi.rf.gd') {
        header("Location: " . "https://tifsec-nsi.rf.gd/TNSI/" . $fonts1[$font1]['link4'] . "#" . $today11dmy);
        exit;
    }
}
?>