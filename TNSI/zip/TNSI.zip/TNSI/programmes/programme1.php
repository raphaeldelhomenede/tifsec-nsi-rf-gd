<section id="programme1" class="content-section">
            <h2>Objectif Principal</h2>
            <p>Concevoir et développer un jeu vidéo complet.</p>

            <hr>

            <h3>1ère Période : Programmation Avancée, Modularité et Premiers Concepts</h3>
            <h4>Septembre - Octobre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Programmation avancée</li>
                <li>Modularité et mise au point des programmes</li>
                <li>Récursivité</li>
                <li>Paradigmes de programmation</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Introduction au projet annuel : présentation du concept de jeu à développer (par exemple, un jeu de plateforme 2D).</li>
                <li>Élaboration du cahier des charges avec les élèves (gameplay, mécanismes de jeu).</li>
                <li>Initiation à la modularité avec Python : organisation des fichiers et modules du jeu.</li>
                <li>Exercices pratiques sur la récursivité : implémentation de mécanismes simples (ex. système de menus).</li>
                <li>Optimisation du code : réduction des temps de calcul et meilleure organisation.</li>
                <li>Exploration des paradigmes de programmation : 
programmation impérative, fonctionnelle et orientée objet appliqués à 
des sous-parties du jeu.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Premiers modules du jeu (menu principal et écran d’accueil).</li>
                <li>Code initial optimisé.</li>
            </ul>

            <hr>

            <h3>2ème Période : Structures de Données et Bases de Programmation Graphique</h3>
            <h4>Novembre - Décembre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Interface et implémentation des structures de données</li>
                <li>Structures arborescentes</li>
                <li>Graphes</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Implémentation des structures de données pour le jeu (ex. gestion des niveaux ou inventaires).</li>
                <li>Introduction aux structures arborescentes : création d’un système de progression (arbre des niveaux).</li>
                <li>Manipulation des graphes : modélisation de cartes de jeu ou réseaux d'interconnexion (ex. système de téléportation ou ennemis).</li>
                <li>Découverte de Pygame : introduction aux bases du moteur graphique.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Implémentation des mécanismes de navigation et du système de progression dans le jeu.</li>
                <li>Prototype graphique simple avec Pygame.</li>
            </ul>

            <hr>

            <h3>3ème Période : Conception et Gestion des Bases de Données</h3>
            <h4>Janvier - Février</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Conception de bases de données</li>
                <li>Systèmes de gestion de bases de données – SQL</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Conception et modélisation de la base de données du jeu (sauvegarde des scores, gestion des utilisateurs).</li>
                <li>Implémentation avec SQLite et requêtes SQL.</li>
                <li>Intégration de la base de données au projet Python (liaison avec Pygame pour gérer les sauvegardes).</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Système de sauvegarde et chargement des parties.</li>
                <li>Fonctionnalités de gestion de profils joueurs.</li>
            </ul>

            <hr>

            <h3>4ème Période : Systèmes et Communication</h3>
            <h4>Mars - Avril</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Composants et processus</li>
                <li>Protocoles de routage et sécurisation des communications</li>
                <li>Programmes et données – Calculabilité</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Exploration des processus et de la concurrence : implémentation de mécanismes de jeu asynchrones (ex. ennemis IA).</li>
                <li>Initiation aux protocoles de communication : système multijoueur basique (local).</li>
                <li>Discussions sur la calculabilité et les limitations des programmes.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Prototype de fonctionnalité multijoueur local.</li>
                <li>Gestion des interactions concurrentes (ex. plusieurs joueurs simultanément).</li>
            </ul>

            <hr>

            <h3>5ème Période : IA et Finalisation du Projet</h3>
            <h4>Mai</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Initiation à l’intelligence artificielle</li>
                <li>Les commentaires et docstrings</li>
                <li>GitHub</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Introduction aux concepts de base de l’IA : algorithmes simples appliqués au jeu (ex. comportements des ennemis).</li>
                <li>Améliorations finales avec Pygame : animations, effets visuels.</li>
                <li>Rédaction de commentaires et docstrings pour une documentation claire.</li>
                <li>Introduction à GitHub : gestion des versions du projet, travail collaboratif.</li>
                <li>Test et validation du jeu par les élèves.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Jeu final optimisé, bien documenté, et disponible sur un dépôt GitHub.</li>
                <li>Rapport final sur les compétences acquises et bilan du projet.</li>
            </ul>
        </section>