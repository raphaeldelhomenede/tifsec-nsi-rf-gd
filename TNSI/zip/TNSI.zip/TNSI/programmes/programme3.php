<section id="programme3" class="content-section">
            <h2>Objectif Principal</h2>
            <p>Concevoir et développer une application Python complète 
pour gérer les épisodes de mangas vus, ceux qu’il reste à voir, ainsi 
que les chapitres de mangas lus et ceux qu’il reste à lire.</p>

            <hr>

            <h3>1ère Période : Programmation Avancée, Modularité et Premiers Concepts</h3>
            <h4>Septembre - Octobre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Programmation avancée</li>
                <li>Modularité et mise au point des programmes</li>
                <li>Récursivité</li>
                <li>Paradigmes de programmation</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Introduction au projet annuel : présentation du 
concept d’application à développer (gestion des épisodes et chapitres de
 mangas).</li>
                <li>Élaboration du cahier des charges avec les élèves (fonctionnalités principales : ajout, suivi, et statistiques).</li>
                <li>Initiation à la modularité avec Python : organisation des fichiers et modules de l’application.</li>
                <li>Exercices pratiques sur la récursivité : 
implémentation de mécanismes simples (ex. navigation entre listes 
d’épisodes et chapitres).</li>
                <li>Optimisation du code : réduction des temps de calcul et meilleure organisation.</li>
                <li>Exploration des paradigmes de programmation : 
programmation impérative, fonctionnelle et orientée objet appliqués à 
des sous-parties de l’application.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Premiers modules de l’application (menu principal et écran d’accueil).</li>
                <li>Code initial optimisé.</li>
            </ul>

            <hr>

            <h3>2ème Période : Structures de Données et Interfaces Graphiques</h3>
            <h4>Novembre - Décembre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Interface et implémentation des structures de données</li>
                <li>Structures arborescentes</li>
                <li>Graphes</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Implémentation des structures de données pour l’application (ex. gestion des séries de mangas, épisodes, et chapitres).</li>
                <li>Introduction aux structures arborescentes : création d’un système de classification des séries par genre ou statut.</li>
                <li>Manipulation des graphes : modélisation des relations entre épisodes ou chapitres (ex. arcs pour progression ou dépendances).</li>
                <li>Introduction à tkinter : création de fenêtres et composants graphiques basiques.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Interfaces graphiques simples pour la saisie et la visualisation des données.</li>
                <li>Implémentation des mécanismes de navigation dans l’application.</li>
            </ul>

            <hr>

            <h3>3ème Période : Conception et Gestion des Bases de Données</h3>
            <h4>Janvier - Février</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Conception de bases de données</li>
                <li>Systèmes de gestion de bases de données – SQL</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Conception et modélisation de la base de données de l’application (sauvegarde des épisodes vus, chapitres lus, statistiques).</li>
                <li>Implémentation avec SQLite et requêtes SQL.</li>
                <li>Intégration de la base de données au projet Python (liaison avec tkinter pour afficher et mettre à jour les données).</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Système de sauvegarde et affichage des données.</li>
                <li>Fonctionnalités de gestion de l’historique des épisodes et chapitres.</li>
            </ul>

            <hr>

            <h3>4ème Période : Systèmes, IA et Finalisation</h3>
            <h4>Mars - Mai</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Composants et processus</li>
                <li>Protocoles de routage et sécurisation des communications</li>
                <li>Initiation à l’intelligence artificielle</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Exploration des processus et de la concurrence : 
implémentation de mécanismes d’analyse en temps réel (ex. progression 
des séries en direct).</li>
                <li>Discussions sur la sécurisation des données : cryptage des données sensibles (ex. profils utilisateurs).</li>
                <li>Introduction aux concepts de base de l’IA : 
algorithmes simples pour analyser les préférences de l’utilisateur (ex. 
recommandations de séries).</li>
                <li>Améliorations finales avec tkinter : ajout d’animations ou d’effets visuels pour l’interface.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Application finale prête à être utilisée.</li>
                <li>Documentation complète et dépôt GitHub avec gestion des versions.</li>
            </ul>
        </section>