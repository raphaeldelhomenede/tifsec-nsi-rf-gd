<section id="programme2" class="content-section">
            <h2>Objectif Principal</h2>
            <p>Concevoir et développer une application Python complète pour gérer les dépenses d’un foyer français.</p>

            <hr>

            <h3>1ère Période : Programmation Avancée, Modularité et Premiers Concepts</h3>
            <h4>Septembre - Octobre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Programmation avancée</li>
                <li>Modularité et mise au point des programmes</li>
                <li>Récursivité</li>
                <li>Paradigmes de programmation</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Introduction au projet annuel : présentation du concept d’application (gestion des dépenses).</li>
                <li>Élaboration du cahier des charges avec les élèves 
(fonctionnalités principales : suivi des dépenses, gestion des 
catégories, budget).</li>
                <li>Initiation à la modularité avec Python : organisation des fichiers et modules du projet.</li>
                <li>Exercices pratiques sur la récursivité : implémentation d’algorithmes simples pour le traitement des données.</li>
                <li>Optimisation du code : réduction des temps de calcul et meilleure organisation.</li>
                <li>Exploration des paradigmes de programmation : 
programmation impérative, fonctionnelle et orientée objet appliqués à 
des sous-parties du projet.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Premiers modules de l’application (interface de base et logique métier simple).</li>
                <li>Code initial optimisé.</li>
            </ul>

            <hr>

            <h3>2ème Période : Structures de Données et Interfaces Graphiques</h3>
            <h4>Novembre - Décembre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Interface et implémentation des structures de données</li>
                <li>Conception d’interfaces graphiques (Tkinter)</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Implémentation des structures de données pour gérer les dépenses (ex. dictionnaires pour catégories, listes pour transactions).</li>
                <li>Création de l’interface graphique de base avec Tkinter (ajout, suppression et visualisation des dépenses).</li>
                <li>Interaction entre l’interface graphique et la logique métier.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Interface fonctionnelle pour gérer les dépenses avec des fonctionnalités de base.</li>
                <li>Visualisation des dépenses par catégorie.</li>
            </ul>

            <hr>

            <h3>3ème Période : Gestion des Bases de Données</h3>
            <h4>Janvier - Février</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Conception de bases de données</li>
                <li>Systèmes de gestion de bases de données – SQL</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Conception et modélisation de la base de données pour stocker les transactions et catégories.</li>
                <li>Implémentation avec SQLite et requêtes SQL.</li>
                <li>Intégration de la base de données au projet Python : sauvegarde et chargement des données via l’interface Tkinter.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Système de sauvegarde et chargement des données de l’application.</li>
                <li>Gestion efficace des transactions et des catégories à partir de la base de données.</li>
            </ul>

            <hr>

            <h3>4ème Période : Analyse, Graphiques et Finalisation</h3>
            <h4>Mars - Avril</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Visualisation des données</li>
                <li>Composants et processus</li>
                <li>Protocoles de sécurisation des données</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Ajout de fonctionnalités d’analyse : calcul des dépenses mensuelles, dépassements de budget.</li>
                <li>Création de graphiques (par exemple avec Matplotlib) pour visualiser les dépenses.</li>
                <li>Implémentation de la sécurisation des données : cryptage basique des informations sensibles.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Application avec visualisation des données (tableaux et graphiques).</li>
                <li>Système sécurisé pour les données sensibles.</li>
            </ul>

            <hr>

            <h3>5ème Période : Documentation et Présentation</h3>
            <h4>Mai</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Les commentaires et docstrings</li>
                <li>GitHub</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Rédaction de commentaires et docstrings pour une documentation claire et complète.</li>
                <li>Introduction à GitHub : gestion des versions du projet, travail collaboratif.</li>
                <li>Préparation de la présentation finale : test et validation de l’application.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Application finalisée, bien documentée, et disponible sur un dépôt GitHub.</li>
                <li>Rapport final sur les compétences acquises et bilan du projet.</li>
            </ul>
        </section>