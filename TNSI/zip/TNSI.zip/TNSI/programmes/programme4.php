<section id="programme4" class="content-section">
            <h2>Objectif Principal</h2>
            <p>Concevoir et développer un site web complet en Python.</p>

            <hr>

            <h3>1ère Période : Programmation Avancée, Modularité et Premiers Concepts</h3>
            <h4>Septembre - Octobre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Programmation avancée</li>
                <li>Modularité et mise au point des programmes</li>
                <li>Récursivité</li>
                <li>Paradigmes de programmation</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Introduction au projet annuel : création d’un site 
web pour gérer un contenu spécifique (par exemple, un gestionnaire de 
ressources éducatives).</li>
                <li>Élaboration du cahier des charges avec les élèves (pages principales, fonctionnalités de base).</li>
                <li>Initiation à la modularité avec Python : organisation des fichiers et modules Flask.</li>
                <li>Exercices pratiques sur la récursivité : implémentation d’un algorithme de navigation dans des catégories ou sous-menus.</li>
                <li>Exploration des paradigmes de programmation : application des principes au backend Flask.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Structure de base du site web (routes principales, navigation).</li>
                <li>Modules Flask organisés pour les différentes fonctionnalités.</li>
            </ul>

            <hr>

            <h3>2ème Période : Structures de Données et Interfaces Web</h3>
            <h4>Novembre - Décembre</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Interface et implémentation des structures de données</li>
                <li>Structures arborescentes</li>
                <li>Graphes</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Implémentation des structures de données pour le site (ex. gestion de listes ou bases de données temporaires).</li>
                <li>Introduction aux structures arborescentes : création
 d’un système de navigation basé sur une hiérarchie (ex. catégories, 
sous-catégories).</li>
                <li>Manipulation des graphes : modélisation des relations entre les données (ex. liens entre articles ou ressources).</li>
                <li>Création d’interfaces web basiques avec HTML, CSS, et intégration dans Flask.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Navigation fonctionnelle avec des données dynamiques générées par Flask.</li>
                <li>Structuration claire des pages et interactions utilisateur.</li>
            </ul>

            <hr>

            <h3>3ème Période : Conception et Gestion des Bases de Données</h3>
            <h4>Janvier - Février</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Conception de bases de données</li>
                <li>Systèmes de gestion de bases de données – SQL</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Conception et modélisation de la base de données pour le site (ex. gestion des utilisateurs, des ressources).</li>
                <li>Implémentation avec SQLite et requêtes SQL pour gérer les données du site.</li>
                <li>Intégration de la base de données avec Flask : création de fonctionnalités CRUD (Create, Read, Update, Delete).</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Base de données fonctionnelle intégrée au site.</li>
                <li>Pages web permettant de gérer les données de manière dynamique.</li>
            </ul>

            <hr>

            <h3>4ème Période : Systèmes, IA et Finalisation</h3>
            <h4>Mars - Mai</h4>
            <h5>Thèmes abordés :</h5>
            <ul>
                <li>Composants et processus</li>
                <li>Protocoles de routage et sécurisation des communications</li>
                <li>Initiation à l’intelligence artificielle</li>
            </ul>
            <h5>Activités :</h5>
            <ul>
                <li>Implémentation de fonctionnalités avancées : gestion des processus pour les tâches asynchrones.</li>
                <li>Discussions sur la sécurisation des communications :
 introduction au HTTPS, gestion des utilisateurs et mots de passe avec 
Flask.</li>
                <li>Introduction aux concepts de base de l’IA : 
algorithmes simples pour personnaliser le contenu (ex. recommandations 
basées sur les données utilisateurs).</li>
                <li>Améliorations finales avec Flask : gestion des erreurs, optimisation des performances.</li>
            </ul>
            <h5>Livrable :</h5>
            <ul>
                <li>Site web complet, incluant les fonctionnalités de personnalisation et de sécurité.</li>
                <li>Documentation complète et dépôt GitHub avec gestion des versions.</li>
            </ul>
        </section>